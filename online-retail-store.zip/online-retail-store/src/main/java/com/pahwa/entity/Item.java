package com.pahwa.entity;



import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by ENVY ULTRABOOK on 29-07-2018.
 */
@Entity
@Table(name="ITEM")
public class Item implements Serializable {
    private static final long serialVersionUID = 1L;

    private Long itemid;
    private String itemName;
    private Integer quantity;
    private double price;
    private Category category;
    private double totalCost;

    public Item() {
    }

    public Item(String itemName, int quantity, double price, Category category, double totalCost) {
        this.itemName = itemName;
        this.quantity = quantity;
        this.price = price;
        this.category = category;
        this.totalCost = totalCost;
    }

    @Id
    @Column(name = "ITEM_ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    public Long getItemid() {
        return this.itemid;
    }

    public void setItemid(Long itemid) {
        this.itemid = itemid;
    }
    @Column(name = "ITEM_NAME", unique = true, nullable = false, length = 100)
    public String getItemName() {
        return this.itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }
    @Column(name = "QUANTITY")
    public int getQuantity() {
        return this.quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Column(name = "PRICE")
    public double getPrice() {
        return this.price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    @OneToOne(cascade = CascadeType.ALL)
    public Category getCategory() {
        return this.category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
    @Column(name = "TOTAL_COST")
    public double getTotalCost() {
        return this.totalCost;
    }

    public void setTotalCost(double totalCost) {
        this.totalCost = totalCost;
    }
}
