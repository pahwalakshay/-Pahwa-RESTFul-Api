package com.pahwa.service;

import com.pahwa.entity.OnlineRetailBill;
import com.pahwa.entity.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ENVY ULTRABOOK on 29-07-2018.
 */
@Service
public class RetailStoreService {
    private ItemDAORepository itemDAORepository;
    private BillDAORepository billDAORepository;
    private static List<Item> itemList = new ArrayList<>();

    @Autowired
    public RetailStoreService(ItemDAORepository itemDAORepository,BillDAORepository billDAORepository) {
        this.itemDAORepository = itemDAORepository;
        this.billDAORepository = billDAORepository;
    }

    public OnlineRetailBill generateBill(Long itemId, Integer qty){
        Item item = itemDAORepository.findItemByItemId(itemId);
         if(null!= item){
             List<Item> returnedList = categorisedItemAndSetQty(item,qty);
             return  calculateBill(returnedList);
         }
          else {
              throw new InvalidItemIdException("Item ID is invalid",itemId);
         }

    }

    private OnlineRetailBill calculateBill(List<Item> itemLists){
        OnlineRetailBill onlineRetailBill =  new OnlineRetailBill();
        onlineRetailBill.setItemList(itemLists);
        double totalCost = 0.0;
        double totalST = 0.0;
        for (Item e: itemLists) {
        totalCost = totalCost +e.getTotalCost();
        totalST = totalST + e.getTotalCost()*e.getCategory().getSaleTax();
        }
        onlineRetailBill.setTotalCost(totalCost);
        onlineRetailBill.setTotalST(totalST);
        onlineRetailBill.setPayableAmount(onlineRetailBill.getTotalCost()+ onlineRetailBill.getTotalST());
        billDAORepository.updateBill(onlineRetailBill);

        return  onlineRetailBill;

    }
    private List<Item> categorisedItemAndSetQty(Item item,Integer qty){
        if(item.getCategory().getType().equals("A")){
            item.getCategory().setSaleTax(10.0);
            item.setTotalCost(item.getPrice()*qty);
        }
        else if(item.getCategory().getType().equals("B")){
            item.getCategory().setSaleTax(20.0);
            item.setTotalCost(item.getPrice()*qty);
        }
        else if(item.getCategory().getType().equals("C")){
            item.getCategory().setSaleTax(0.0);
            item.setTotalCost(item.getPrice()*qty);
        }
         itemList.add(item);
        return itemList;
    }
}
