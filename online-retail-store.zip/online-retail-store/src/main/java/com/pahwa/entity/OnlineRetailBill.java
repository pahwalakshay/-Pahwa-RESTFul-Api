package com.pahwa.entity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

/**
 * Created by ENVY ULTRABOOK on 29-07-2018.
 */
@Entity
@Table(name="RETAIL_STORE_BILL")
public class OnlineRetailBill implements Serializable {
    private static final long serialVersionUID = 3L;

    private Long billId;
    private List<Item> itemList;
    private static double totalCost;
    private static double totalST;
    private static double payableAmount;

    public OnlineRetailBill() {
    }

    public OnlineRetailBill(List<Item> itemList, double totalCost, double totalST, double payableAmount) {
        this.itemList = itemList;
        this.totalCost = totalCost;
        this.totalST = totalST;
        this.payableAmount = payableAmount;
    }
    @Id
    @Column(name = "BILL_ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    public Long getBillId() {
        return this.billId;
    }


    @OneToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "ITEM_BILL", joinColumns = { @JoinColumn(name = "BILL_ID") }, inverseJoinColumns = { @JoinColumn(name = "ITEM_ID") })
    public List<Item> getItemList() {
        return this.itemList;
    }

    public void setItemList(List<Item> itemList) {
        this.itemList = itemList;
    }

    @Column(name = "TOTAL_COST", nullable = false, length=10)
    public double getTotalCost() {
        return this.totalCost;
    }

    public void setTotalCost(double totalCost) {
        this.totalCost = totalCost;
    }
    @Column(name = "TOTAL_TAX", nullable = false, length=10)
    public double getTotalST() {
        return this.totalST;
    }

    public void setTotalST(double totalST) {
        this.totalST = totalST;
    }
    @Column(name = "GRAND_TOTAL", nullable = false, length=10)
    public double getPayableAmount() {
        return this.payableAmount;
    }

    public void setPayableAmount(double payableAmount) {
        this.payableAmount = payableAmount;
    }

    @Override
    public String toString() {
        return " Retail Store Bill{" +
                "billId :'" + billId + '\'' +
                ", itemList :" + itemList +
                ", totalCost :" + totalCost +
                ", totalST :" + totalST +
                ", payableAmount :" + payableAmount +
                '}';
    }
}
