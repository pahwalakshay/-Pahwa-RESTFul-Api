package com.pahwa.controller;

import com.pahwa.entity.OnlineRetailBill;
import com.pahwa.service.RetailStoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.*;

/**
 * Created by ENVY ULTRABOOK on 29-07-2018.
 */
@RestController
@RequestMapping(value = "/v1/api/")
public class RetailStoreController {

    @Autowired
    private RetailStoreService retailStoreService;

    @RequestMapping( value = "/addItemToBill/itemId/{itemId}/quantity/{quantity}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
    public OnlineRetailBill addItemToBill(@PathVariable("itemId")  Long itemId, @PathVariable("quantity")Integer quantity){
        Assert.notNull(itemId,"ItemID of item to be added cannot be null");
        Assert.notNull(quantity,"Quantity cannot be null");
        return  retailStoreService.generateBill(itemId,quantity);
    }

}
