package com.pahwa.service;

import com.pahwa.entity.Item;

/**
 * Created by ENVY ULTRABOOK on 29-07-2018.
 */
public interface ItemDAORepository {

    public Item findItemByItemId(Long id);

}
