package com.pahwa.config;

/**
 * Created by ENVY ULTRABOOK on 29-07-2018.
 */

import com.pahwa.service.BillDAORepository;
import com.pahwa.service.BillDAORepositoryImpl;
import com.pahwa.service.ItemDAORepository;
import com.pahwa.service.ItemDAORepositoryImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import javax.sql.DataSource;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = { "com.pahwa" })
public class OnlineRetailStoreConfig {

    @Bean
    public DataSource dataSource(){
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("org.h2.Driver");
        dataSource.setUrl("jdbc:h2:tcp://localhost/~/test");
        dataSource.setUsername("sa");
        dataSource.setPassword("");
         return  dataSource;
    }

    @Bean
    public JdbcTemplate jdbcTemplate() {
        JdbcTemplate jdbcTemplate = new JdbcTemplate();
        jdbcTemplate.setDataSource(dataSource());
        return jdbcTemplate;
    }

    @Bean
    public ItemDAORepository itemDAO(){
        ItemDAORepositoryImpl itemDao = new ItemDAORepositoryImpl();
        itemDao.setJdbcTemplate(jdbcTemplate());
        return itemDao;
    }
    @Bean
    public BillDAORepository billDAO(){
        BillDAORepositoryImpl billDao = new BillDAORepositoryImpl();
        billDao.setJdbcTemplate(jdbcTemplate());
        return billDao;
    }
}
