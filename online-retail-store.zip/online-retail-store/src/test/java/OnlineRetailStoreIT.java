import com.pahwa.config.OnlineRetailStoreConfig;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockServletContext;
import org.springframework.mock.web.MockSessionCookieConfig;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultHandler;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import javax.servlet.ServletContext;

import static org.springframework.test.web.client.match.MockRestRequestMatchers.content;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Created by ENVY ULTRABOOK on 30-07-2018.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {OnlineRetailStoreConfig.class })
@WebAppConfiguration
public class OnlineRetailStoreIT {

    @Autowired
    private WebApplicationContext wac;

    private MockMvc mockMvc;

    private  ResultHandler resultHandler;

    @Before
    public void setup() throws Exception {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
    }

    @Test
    public void givenWac_whenServletContext_thenItProvidesRetailStoreController() {
        ServletContext servletContext = wac.getServletContext();
        servletContext.setAttribute("contextConfigLocation",MockSessionCookieConfig.class);
        Assert.assertNotNull(servletContext);
        Assert.assertTrue(servletContext instanceof MockServletContext);
        Assert.assertNotNull(wac.getBean("retailStoreController"));
    }

    @Test
    public void givenRetailBillURIWithPathVariable_whenMockMVC_thenResponseOK() throws Exception {

        this.mockMvc.perform(put("/v1/api/addItemToBill/itemId/{itemId}/quantity/{quantity}", "1234","2"))
                .andExpect((ResultMatcher) content().contentType("application/json;charset=UTF-8"));


    }
}
