package com.pahwa.service;

import com.pahwa.entity.OnlineRetailBill;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Types;

/**
 * Created by ENVY ULTRABOOK on 29-07-2018.
 */
@Repository
public class BillDAORepositoryImpl implements BillDAORepository {
    private JdbcTemplate jdbcTemplate;

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate){
        this.jdbcTemplate = jdbcTemplate;
    }
    @Override
    public void updateBill(OnlineRetailBill onlineRetailBill) {
        String  insertSql =
        "INSERT INTO RETAIL_STORE_BILL (" +
        " ITEM_BILL, " +
        " TOTAL_COST, " +
        " TOTAL_TAX, " +
        " GRAND_TOTAL) " +
        "VALUES (?, ?, ?, ?)";
        Object[] params = new Object[] {  onlineRetailBill.getItemList(), onlineRetailBill.getTotalCost(), onlineRetailBill.getTotalST(),onlineRetailBill.getPayableAmount() };

        int[] types = new int[] { Types.JAVA_OBJECT, Types.FLOAT, Types.FLOAT, Types.FLOAT };

        int updatedROWs = jdbcTemplate.update(insertSql,params,types);




    }
}
