package com.pahwa.service;

import com.pahwa.entity.OnlineRetailBill;

/**
 * Created by ENVY ULTRABOOK on 29-07-2018.
 */
public interface BillDAORepository {
    public void updateBill(OnlineRetailBill onlineRetailBill);
}
