package com.pahwa.controller;

import com.pahwa.service.InvalidItemIdException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * Created by ENVY ULTRABOOK on 29-07-2018.
 */
@ControllerAdvice
public class ExceptionHandlerController  extends ResponseEntityExceptionHandler {

    @ExceptionHandler({ InvalidItemIdException.class })
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> handleInvalidItemIDException(
            Exception ex, WebRequest request) {
        return new ResponseEntity<Object>(
                "Invalid Item ID trying to add to Bill", new HttpHeaders(), HttpStatus.FORBIDDEN);
    }

}
