package com.pahwa.entity;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by ENVY ULTRABOOK on 29-07-2018.
 */
@Entity
@Table(name="CATEGORY")
public class Category implements Serializable{
    private static final long serialVersionUID = 2L;

    private int categoryId;
    private String type;
    private double saleTax;

    public Category() {
    }

    public Category(String type, double saleTax) {
        this.type = type;
        this.saleTax = saleTax;
    }


    @Id
    @Column(name = "CATEGORY_ID", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    public int getCategoryId() {
        return this.categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }
    @Column(name = "TYPE", unique = true, nullable = false)
    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }
    @Column(name = "SALE_TAX", unique = true, nullable = false)
    public double getSaleTax() {
        return this.saleTax;
    }

    public void setSaleTax(double saleTax) {
        this.saleTax = saleTax;
    }
}
