package com.pahwa.service;

/**
 * Created by ENVY ULTRABOOK on 30-07-2018.
 */
public class InvalidItemIdException extends RuntimeException {
    private Long itemId;

    public InvalidItemIdException(String message, Long itemId) {
        super(message);
        this.itemId = itemId;
    }
}
