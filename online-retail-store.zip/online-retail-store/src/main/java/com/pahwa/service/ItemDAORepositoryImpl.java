package com.pahwa.service;

import com.pahwa.entity.Item;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

/**
 * Created by ENVY ULTRABOOK on 29-07-2018.
 */
@Repository
public class ItemDAORepositoryImpl implements ItemDAORepository {

    private JdbcTemplate jdbcTemplate;

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate){
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public Item findItemByItemId(Long id) {
        String sql = "select * from ITEM where itemId =?";
        Item item = jdbcTemplate.queryForObject(sql,new Object[]{id},Item.class);
        return item;
    }
}
